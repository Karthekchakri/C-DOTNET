﻿using Microsoft.Extensions.Azure;
using NemsisImport.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NemsisImport.Service
{
    public class ProcessBlob : IFileExtractService
    {
        private IBlobService blobService;
        public ProcessBlob(IBlobService _blobService)
        {
            blobService = _blobService;
        }

        public async Task GetFiles()
        {
            //blobService.
            BlobService blobServ = new BlobService();
            Console.WriteLine("********************List of Containers************************");
            await blobServ.ListContainers();
            Console.WriteLine("**************************************************************");
            Console.WriteLine("**************************************************************");
            Console.WriteLine("******************Save a File/Blob****************************");
            await blobServ.UploadBlobAsync();
            Console.WriteLine("**************************************************************");
            Console.WriteLine("**************************************************************");
            Console.WriteLine("******************List all the blobs of a container with indexTags****************************");
            await blobServ.ListBlobsWithMetadataAsync();
            Console.WriteLine("**************************************************************");
            Console.WriteLine("**************************************************************");
            Console.WriteLine("******************List all the blobs of a container****************************");
            await blobServ.GetAllBlobsinContainer();
            Console.WriteLine("******************List all the blobs of a container****************************");
            Console.WriteLine("******************Move a blob from Source to Processed container****************************");
            await blobServ.MoveFileAsync();
            Console.WriteLine("******************Move a blob from Source to Processed container****************************");



        }
    }
}
